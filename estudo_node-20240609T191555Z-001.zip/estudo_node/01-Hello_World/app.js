console.log("Hello world!")

var n1 = 10
var n2 = 20

function somar(a,b){
    return a+b
}

console.log(somar(n1,n2))