var SomarFunc = require("./modulo/somar")
var SubFunc = require("./modulo/subtrair")
var MultFunc = require("./modulo/multiplicar")
var DivFunc = require("./modulo/dividir")

console.log(SomarFunc(4,7))
console.log(SubFunc(4,7))
console.log(MultFunc(4,7))
console.log(DivFunc(4,7))