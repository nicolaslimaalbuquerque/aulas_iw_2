const Sequelize = require('sequelize')
const sequelize = new Sequelize('test','root','',{
    host:'localhost',
    dialect: 'mysql'
})

// sequelize.authenticate().then(function(){
//     console.log('CONECTADO COM SUCESSO!')
// }).catch(Function(erro){
//     console.log('Houve o seguinte erro' + erro)
// }) 

const Postagen = sequelize.define('postagens',{
    titulo:{
        type: Sequelize.STRING
    },
    conteudo:{
        type: Sequelize.TEXT
    }
} )

const Usuario = sequelize.define('usuarios',{
    nome: {
        type: Sequelize.STRING
    
    },
    sobrenome:{
        type: Sequelize.STRING
    },
    idade:{
        type: Sequelize.STRING
    },
    email:{
        type: Sequelize.STRING
    }
})

// Postagen.sync( force = true)
// Usuario.sync( force = true)

// Postagen.create(
//     titulo : 'PRIMEIRA POSTAGEM',
//     conteudo : 'Conteudo da primeira postagem bla,bla,bla ....'
// )